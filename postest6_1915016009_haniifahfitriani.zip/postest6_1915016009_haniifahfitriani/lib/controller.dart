import 'package:get/get.dart';

class DataController extends GetxController {
  var switchValue = false.obs;
  var alamat = "".obs;
  var nama = "".obs;
  var warnaGroup = "warna".obs;
  List warnaList = ["merah", "hitam", "putih"].obs;
  var tipeGroup = "tipe".obs;
  List tipeList = ["Honda Jazz", "Honda Brio", "Honda Civic"].obs;
}
