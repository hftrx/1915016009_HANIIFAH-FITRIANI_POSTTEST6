import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'controller.dart';
import 'page2.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

Widget buildMobil1(BuildContext context) {
  final urlBurger = "assets/mobil1.png";

  return ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: Container(
      padding: EdgeInsets.only(top: 25, right: 30, left: 30, bottom: 20),
      color: Color.fromARGB(255, 56, 56, 56),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.network(urlBurger, width: 260, height: 100, fit: BoxFit.fill),
          Container(
            padding: EdgeInsets.only(top: 20),
            child: Text(
              'Honda Civic',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontSize: 30,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '\Rp. 900.000.000',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20, bottom: 5),
            child: Column(
              children: [
                SizedBox(
                  width: 100.0,
                  height: 40.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => DetailPage()));
                    },
                    child: Text("Detail"),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white,
                        onPrimary: Color.fromARGB(255, 0, 0, 0),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget buildMobil2(BuildContext context) {
  final urlBurger = "assets/mobil2.png";

  return ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: Container(
      padding: EdgeInsets.only(top: 25, right: 30, left: 30, bottom: 20),
      color: Color.fromARGB(255, 56, 56, 56),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.network(urlBurger, width: 260, height: 100, fit: BoxFit.fill),
          Container(
            padding: EdgeInsets.only(top: 20),
            child: Text(
              'Honda Brio',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontSize: 30,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '\Rp. 155.000.000',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20, bottom: 5),
            child: Column(
              children: [
                SizedBox(
                  width: 100.0,
                  height: 40.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => DetailPage2()));
                    },
                    child: Text("Detail"),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white,
                        onPrimary: Color.fromARGB(255, 0, 0, 0),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget buildMobil3(BuildContext context) {
  final urlBurger = "assets/mobil3.png";

  return ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: Container(
      padding: EdgeInsets.only(top: 25, right: 30, left: 30, bottom: 20),
      color: Color.fromARGB(255, 56, 56, 56),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.network(urlBurger, width: 260, height: 100, fit: BoxFit.fill),
          Container(
            padding: EdgeInsets.only(top: 20),
            child: Text(
              'Honda HR-V',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontSize: 30,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '\Rp. 360.000.000',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20, bottom: 5),
            child: Column(
              children: [
                SizedBox(
                  width: 100.0,
                  height: 40.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => DetailPage3()));
                    },
                    child: Text("Detail"),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white,
                        onPrimary: Color.fromARGB(255, 0, 0, 0),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

class showroomcar extends StatelessWidget {
  const showroomcar({Key? key}) : super(key: key);

  get child => null;

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Postest 6 Haniifah Fitriani'),
        backgroundColor: Color.fromARGB(255, 134, 0, 0),
      ),
      backgroundColor: Color.fromARGB(255, 0, 0, 0),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 100, bottom: 15, left: 30, right: 50),
            child: (Text("SHOWROOM MOBIL HONDA",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 50,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 255, 255, 255),
                  letterSpacing: 2,
                  wordSpacing: 12,
                ))),
          ),
          Container(
            margin: EdgeInsets.only(top: 25, bottom: 20, left: 30, right: 50),
            child: (Text(
                "Kami menyediakan berbagai tipe mobil Honda dengan harga yang terjangkau",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 121, 121, 121),
                ))),
          ),
          Container(
            width: 500,
            height: 350,
            margin: EdgeInsets.only(top: 5, bottom: 20),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/showroom.png"),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 15),
            child: Column(
              children: [
                SizedBox(
                  width: 200.0,
                  height: 50.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => MainPage()));
                    },
                    child: Text("Mulai"),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white,
                        onPrimary: Color.fromARGB(255, 0, 0, 0),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(50))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MainPage extends StatelessWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        backgroundColor: Color.fromARGB(255, 134, 0, 0),
      ),
      backgroundColor: Color.fromARGB(255, 0, 0, 0),
      drawer: Drawer(
        child: ListView(padding: EdgeInsets.all(0.0), children: <Widget>[
          UserAccountsDrawerHeader(
            accountName: Text('Haniifah Fitriani'),
            accountEmail: Text('haniifah.fitriani@gmail.com'),
            currentAccountPicture: CircleAvatar(
              backgroundImage: ExactAssetImage('assets/hanii.jpeg'),
            ),
            onDetailsPressed: () {},
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/fundo.jpg'), fit: BoxFit.fill)),
          ),
          ListTile(
            title: Text('Home'),
            leading: Icon(Icons.home),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => MainPage()));
            },
          ),
          Divider(),
          ListTile(
            title: Text('Form Pemesanan'),
            leading: Icon(Icons.wysiwyg),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => FormPage()));
            },
          ),
          ListTile(
              title: Text('Tutup'),
              leading: Icon(Icons.close),
              onTap: () {
                Navigator.of(context).pop();
              }),
        ]),
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 50, bottom: 40, left: 30),
            child: (Text("Pilih Mobil Mu!",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 255, 255, 255),
                  letterSpacing: 2,
                ))),
          ),
          Center(child: buildMobil1(context)),
          Container(
            margin: EdgeInsets.only(top: 40),
          ),
          Center(child: buildMobil2(context)),
          Container(
            margin: EdgeInsets.only(top: 40),
          ),
          Center(child: buildMobil3(context)),
          Container(
            margin: EdgeInsets.only(bottom: 40),
          ),
        ],
      ),
    );
  }
}

class DetailPage extends StatelessWidget {
  const DetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          title: const Text('Detail'),
          backgroundColor: Color.fromARGB(255, 134, 0, 0),
        ),
        backgroundColor: Color.fromARGB(255, 0, 0, 0),
        body: ListView(
          children: [
            Container(
              margin: EdgeInsets.only(top: 30, bottom: 15),
              child: const Center(
                  child: Text("CIVIC Type R 6 Speed M/T",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ))),
            ),
            Container(
              width: 500,
              height: 350,
              margin: EdgeInsets.only(top: 5),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/mobil1.png"),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: Material(
          child: InkWell(
            child: Container(
              child: ListView(
                children: [
                  Container(
                      padding: EdgeInsets.only(top: 15),
                      margin: EdgeInsets.all(10),
                      child: Column(children: [
                        Text(
                          'Spesifikasi',
                          style: TextStyle(
                              fontSize: 30,
                              color: Color.fromARGB(255, 0, 0, 0),
                              fontWeight: FontWeight.w600),
                        ),
                      ])),
                  Container(
                    margin: EdgeInsets.all(10),
                    child: Column(children: [
                      Text(
                        '2.0 L VTEC Turbo Engine 310 PS\n6 M/T\n20 Alloy Wheel\n3 Driving Mode with Adaptive Damper System',
                        style: TextStyle(
                          fontSize: 20,
                          color: Color.fromARGB(255, 255, 255, 255),
                          fontWeight: FontWeight.w500,
                          height: 2,
                        ),
                      ),
                    ]),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 10),
                    child: Column(
                      children: [
                        SizedBox(
                          width: 200.0,
                          height: 50.0,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => FormPage()));
                            },
                            child: Text("Beli Sekarang"),
                            style: ElevatedButton.styleFrom(
                                primary: Color.fromARGB(255, 0, 0, 0),
                                onPrimary: Color.fromARGB(255, 255, 255, 255),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50))),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50)),
                color: Color.fromARGB(255, 107, 107, 107),
              ),
              height: 350,
            ),
          ),
          color: Colors.transparent,
        ));
  }
}

class DetailPage2 extends StatelessWidget {
  const DetailPage2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          title: const Text('Detail'),
          backgroundColor: Color.fromARGB(255, 134, 0, 0),
        ),
        backgroundColor: Color.fromARGB(255, 0, 0, 0),
        body: ListView(
          children: [
            Container(
              margin: EdgeInsets.only(top: 30, bottom: 15),
              child: const Center(
                  child: Text("Honda Brio Satya S M/T",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ))),
            ),
            Container(
              width: 500,
              height: 350,
              margin: EdgeInsets.only(top: 5),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/mobil2.png"),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: Material(
          child: InkWell(
            child: Container(
              child: ListView(
                children: [
                  Container(
                      padding: EdgeInsets.only(top: 15),
                      margin: EdgeInsets.all(10),
                      child: Column(children: [
                        Text(
                          'Spesifikasi',
                          style: TextStyle(
                              fontSize: 30,
                              color: Color.fromARGB(255, 0, 0, 0),
                              fontWeight: FontWeight.w600),
                        ),
                      ])),
                  Container(
                    margin: EdgeInsets.all(10),
                    child: Column(children: [
                      Text(
                        '1.2L i-VTEC 90PS\n5M/T\nChrome Front Grille\nHeadlamp with LED Light Guide',
                        style: TextStyle(
                          fontSize: 20,
                          color: Color.fromARGB(255, 255, 255, 255),
                          fontWeight: FontWeight.w500,
                          height: 2,
                        ),
                      ),
                    ]),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 10),
                    child: Column(
                      children: [
                        SizedBox(
                          width: 200.0,
                          height: 50.0,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => FormPage()));
                            },
                            child: Text("Beli Sekarang"),
                            style: ElevatedButton.styleFrom(
                                primary: Color.fromARGB(255, 0, 0, 0),
                                onPrimary: Color.fromARGB(255, 255, 255, 255),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50))),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50)),
                color: Color.fromARGB(255, 107, 107, 107),
              ),
              height: 350,
            ),
          ),
          color: Colors.transparent,
        ));
  }
}

class DetailPage3 extends StatelessWidget {
  const DetailPage3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          title: const Text('Detail'),
          backgroundColor: Color.fromARGB(255, 134, 0, 0),
        ),
        backgroundColor: Color.fromARGB(255, 0, 0, 0),
        body: ListView(
          children: [
            Container(
              margin: EdgeInsets.only(top: 30, bottom: 15),
              child: const Center(
                  child: Text("HR-V S CVT",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ))),
            ),
            Container(
              width: 500,
              height: 350,
              margin: EdgeInsets.only(top: 5),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/mobil3.png"),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: Material(
          child: InkWell(
            child: Container(
              child: ListView(
                children: [
                  Container(
                      padding: EdgeInsets.only(top: 15),
                      margin: EdgeInsets.all(10),
                      child: Column(children: [
                        Text(
                          'Spesifikasi',
                          style: TextStyle(
                              fontSize: 30,
                              color: Color.fromARGB(255, 0, 0, 0),
                              fontWeight: FontWeight.w600),
                        ),
                      ])),
                  Container(
                    margin: EdgeInsets.all(10),
                    child: Column(children: [
                      Text(
                        '1.5L DOHC i-VTEC Engine\nHonda Sensing\nFull LED Headlights with LED DRL\n17" Alloy Wheels',
                        style: TextStyle(
                          fontSize: 20,
                          color: Color.fromARGB(255, 255, 255, 255),
                          fontWeight: FontWeight.w500,
                          height: 2,
                        ),
                      ),
                    ]),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 10),
                    child: Column(
                      children: [
                        SizedBox(
                          width: 200.0,
                          height: 50.0,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => FormPage()));
                            },
                            child: Text("Beli Sekarang"),
                            style: ElevatedButton.styleFrom(
                                primary: Color.fromARGB(255, 0, 0, 0),
                                onPrimary: Color.fromARGB(255, 255, 255, 255),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50))),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50)),
                color: Color.fromARGB(255, 107, 107, 107),
              ),
              height: 350,
            ),
          ),
          color: Colors.transparent,
        ));
  }
}

class FormPage extends StatefulWidget {
  const FormPage({Key? key}) : super(key: key);

  @override
  State<FormPage> createState() => _MyFormPageState();
}

class _MyFormPageState extends State<FormPage> {
  final ctrlnamaLengkap = TextEditingController();
  final ctrlAlamat = TextEditingController();
  final DataController myDataController = Get.put(DataController());
  bool isYakin = false;
  // DateTime? _dateTime;
  DateTime selectedDate = DateTime.now();
  Future<Null> _selectDate(BuildContext context) async {
    // Initial DateTime FIinal Picked
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Form Pemesanan"),
        backgroundColor: Colors.black,
      ),
      body: ListView(
        children: [
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 40, bottom: 40),
                child: const Center(
                    child: Text("Form Pemesanan Mobil Honda",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ))),
              ),
              Container(
                margin: EdgeInsets.only(right: 40, left: 40),
                child: Column(
                  children: [
                    TextField(
                      controller: ctrlnamaLengkap,
                      decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: "Isi Nama Legkap",
                          labelText: "Nama Pembeli"),
                    ),
                    SizedBox(height: 30),
                    TextFormField(
                      controller: ctrlAlamat,
                      decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: "Isi Alamat Lengkap",
                          labelText: "Alamat"),
                    ),
                    SizedBox(height: 30),
                    Container(
                      margin: EdgeInsets.only(top: 40, bottom: 30),
                      child: Column(
                        children: [
                          Text("Pilih Tipe Mobil",
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              )),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 10),
                child: Column(
                  children: [
                    ListTile(
                        title: Text("Honda Jazz"),
                        leading: Obx(
                          () => Radio(
                            groupValue: myDataController.tipeGroup.value,
                            value: myDataController.tipeList[0],
                            onChanged: (dynamic value) {
                              myDataController.tipeGroup.value =
                                  value.toString();
                            },
                          ),
                        )),
                    ListTile(
                        title: Text("Honda Brio"),
                        leading: Obx(
                          () => Radio(
                            groupValue: myDataController.tipeGroup.value,
                            value: myDataController.tipeList[1],
                            onChanged: (dynamic value) {
                              myDataController.tipeGroup.value =
                                  value.toString();
                            },
                          ),
                        )),
                    ListTile(
                      title: Text("Honda Civic"),
                      leading: Obx(
                        () => Radio(
                          groupValue: myDataController.tipeGroup.value,
                          value: myDataController.tipeList[2],
                          onChanged: (dynamic value) {
                            myDataController.tipeGroup.value = value.toString();
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 30, bottom: 30),
                child: Column(
                  children: [
                    Text("Pilih Warna Mobil",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        )),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 10),
                child: Column(
                  children: [
                    ListTile(
                      title: Text("Merah"),
                      leading: Obx(
                        () => Radio(
                          groupValue: myDataController.warnaGroup.value,
                          value: myDataController.warnaList[0],
                          onChanged: (dynamic value) {
                            myDataController.warnaGroup.value =
                                value.toString();
                          },
                        ),
                      ),
                    ),
                    ListTile(
                      title: Text("Hitam"),
                      leading: Obx(
                        () => Radio(
                          groupValue: myDataController.warnaGroup.value,
                          value: myDataController.warnaList[1],
                          onChanged: (dynamic value) {
                            myDataController.warnaGroup.value =
                                value.toString();
                          },
                        ),
                      ),
                    ),
                    ListTile(
                      title: Text("Putih"),
                      leading: Obx(
                        () => Radio(
                          groupValue: myDataController.warnaGroup.value,
                          value: myDataController.warnaList[2],
                          onChanged: (dynamic value) {
                            myDataController.warnaGroup.value =
                                value.toString();
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 30, bottom: 20),
                child: Column(
                  children: [
                    Text("Pilih Tanggal Pemesanan",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        )),
                  ],
                ),
              ),
              ElevatedButton(
                child: const Text("Pilih Tanggal"),
                onPressed: () {
                  showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2099),
                  ).then((date) {
                    setState(() {
                      selectedDate = date!;
                    });
                  });
                },
              ),
              Container(
                margin: EdgeInsets.only(top: 30),
                child: Column(
                  children: [
                    Text(
                        "Tanggal Pemesanan : " +
                            "${selectedDate}".split(' ')[0],
                        style: TextStyle(
                          fontSize: 17,
                        )),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 55, bottom: 10),
                child: Column(
                  children: [
                    Text(
                        "Apakah data diatas sudah benar?\nSilahkan ceklist box dibawah",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        )),
                  ],
                ),
              ),
              Container(
                  margin: EdgeInsets.only(top: 10, left:12),
                  child: Column(
                    children: [
                      ListTile(
                        title: Text(
                            "Saya yakin bahwa data yang saya isi diatas sudah benar."),
                        leading: Checkbox(
                          value: isYakin,
                          onChanged: (bool? value) {
                            setState(() {
                              isYakin = value!;
                            });
                          },
                        ),
                      ),
                    ],
                  )),
              Container(
                margin: EdgeInsets.only(top: 20, bottom: 20),
                child: Column(
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        _showMyDialog();
                      },
                      child: Text("Tampilkan Data Pesanan"),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget fadeAlertAnimation(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    return Align(
      child: FadeTransition(
        opacity: animation,
        child: child,
      ),
    );
  }

  Future<void> _showMyDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('KONFIRMASI PESANAN'),
          titleTextStyle: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 20, letterSpacing: 1),
          content: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Text(
                  'Apakah anda yakin ingin memesan?\n',
                  style: TextStyle(fontSize: 17),
                ),
                Text(
                    'Dengan melakukan klik pada tombol "YA",\nanda sudah TIDAK DAPAT membatalkan pesanan.'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('YA'),
              onPressed: () {
                print('Yes');
                Navigator.of(context).pop();
                setState(() {
                  myDataController.nama.value = ctrlnamaLengkap.text;
                  myDataController.alamat.value = ctrlAlamat.text;
                  Get.to(Page2());
                });
              },
            ),
            TextButton(
              child: Text('TIDAK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
