import 'package:flutter/material.dart';
import 'package:splash_screen_view/SplashScreenView.dart';
import 'package:get/get.dart';
import 'package:postest6_1915016009_haniifahfitriani/showroomcar.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    /// Logo with Typer Animated Text example
    Widget splashScreen = SplashScreenView(
      navigateRoute:  const showroomcar(),
      duration: 6000,
      imageSize: 350,
      pageRouteTransition: PageRouteTransition.CupertinoPageRoute,
      imageSrc: "logo.png",
      speed: 100,
      text: "Selamat Datang di ShowRoom Honda",
      textType: TextType.TyperAnimatedText,
      textStyle: const TextStyle(
        fontSize: 25.0,
        color: Colors.white,
        fontWeight: FontWeight.bold,
      ),
      backgroundColor: const Color.fromARGB(255, 0, 0, 0),
    );

    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Showroom Mobil Honda',
      home: splashScreen,
    );
  }
}

