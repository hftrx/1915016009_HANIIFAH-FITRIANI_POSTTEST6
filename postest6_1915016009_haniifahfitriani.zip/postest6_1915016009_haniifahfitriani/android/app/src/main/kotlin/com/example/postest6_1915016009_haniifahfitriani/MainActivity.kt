package com.example.postest6_1915016009_haniifahfitriani

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
